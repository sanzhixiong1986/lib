"use strict";
cc._RF.push(module, 'fbfefKd3mxDwbplPvfAf5Hz', 'bullet');
// scripts/bullet.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        degree: 45,
        speed: 500
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    shoot_to: function shoot_to(degree) {
        this.degree = degree;
        this.vx = this.speed * Math.cos(this.degree * Math.PI / 180);
        this.vy = this.speed * Math.sin(this.degree * Math.PI / 180);

        this.node.angle = this.degree - 90;
    },
    update: function update(dt) {
        this.node.x += this.vx * dt;
        this.node.y += this.vy * dt;

        var w_pos = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
        if (w_pos.x <= 0 || w_pos.x > cc.winSize.width || w_pos.y <= 0 || w_pos.y > cc.winSize.height) {
            this.node.removeFromParent();
        }
    },


    onCollisionEnter: function onCollisionEnter(other, self) {
        // this.node.removeFromParent();

        this.scheduleOnce(function () {
            this.node.removeFromParent();
        }.bind(this), 0.05);
    }
});

cc._RF.pop();