cc.Class({
    extends: cc.Component,

    properties: {
        bullet_prefab: {
            type: cc.Prefab,
            default: null,
        },

        target: {
            type: cc.Node,
            default: null,
        },

        shoot_time: 0.3,

        bullet_root: {
            type: cc.Node,
            default: null,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.now_time = this.shoot_time;
        this.nav_agent = this.target.getComponent("nav_agent");
    },

    shoot_to() {
        if (this.target === null) {
            return;
        }

        // var dst = this.target.getPosition();
        var dst = this.nav_agent.get_next_point();
        
        var src = this.node.getPosition();
        var dir = dst.sub(src);
        var r = Math.atan2(dir.y, dir.x)
        var degree = r * 180 / Math.PI;

        
        var b = cc.instantiate(this.bullet_prefab);
        b.getComponent("bullet").shoot_to(degree);
        this.bullet_root.addChild(b);
        b.setPosition(this.node.getPosition());
    },

    update (dt) {
        if (this.target === null) {
            return;
        }

        var dst = this.target.getPosition();
        var src = this.node.getPosition();
        var dir = dst.sub(src);
        var r = Math.atan2(dir.y, dir.x)
        var degree = r * 180 / Math.PI;
        this.node.angle = degree - 90;

        this.now_time += dt;
        if (this.now_time >= this.shoot_time) {
            this.shoot_to();
            this.now_time = 0;
        }
 
    },
});
