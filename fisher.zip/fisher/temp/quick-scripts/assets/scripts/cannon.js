(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/cannon.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b85f6v7zKxPyqIONYOGVRtT', 'cannon', __filename);
// scripts/cannon.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        bullet_prefab: {
            type: cc.Prefab,
            default: null
        },

        target: {
            type: cc.Node,
            default: null
        },

        shoot_time: 0.3,

        bullet_root: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.now_time = this.shoot_time;
        this.nav_agent = this.target.getComponent("nav_agent");
    },
    shoot_to: function shoot_to() {
        if (this.target === null) {
            return;
        }

        // var dst = this.target.getPosition();
        var dst = this.nav_agent.get_next_point();

        var src = this.node.getPosition();
        var dir = dst.sub(src);
        var r = Math.atan2(dir.y, dir.x);
        var degree = r * 180 / Math.PI;

        var b = cc.instantiate(this.bullet_prefab);
        b.getComponent("bullet").shoot_to(degree);
        this.bullet_root.addChild(b);
        b.setPosition(this.node.getPosition());
    },
    update: function update(dt) {
        if (this.target === null) {
            return;
        }

        var dst = this.target.getPosition();
        var src = this.node.getPosition();
        var dir = dst.sub(src);
        var r = Math.atan2(dir.y, dir.x);
        var degree = r * 180 / Math.PI;
        this.node.angle = degree - 90;

        this.now_time += dt;
        if (this.now_time >= this.shoot_time) {
            this.shoot_to();
            this.now_time = 0;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=cannon.js.map
        